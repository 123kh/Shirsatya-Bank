
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
			<div class="page-content">
				<div class="row">
					<div class="col-md-12 mx-auto" >
						<div class="card">
							<div class="card-body">
								<div class="card-title d-flex align-items-center">
								
									<h5 class="mb-0 text-primary">Loan Application</h5>
								</div>
								<hr>
								
								<form class="row g-2" method="post" action="<?php echo e(route('update_loanapp')); ?>">
									<?php echo csrf_field(); ?>
									<input type="hidden"  name="id"  value="<?php echo e($editloanapp->id); ?>" >
									<div class="col-md-2">
										<label>Select Loan Scheme*</label>
										<select class="form-select "
											aria-label="Default select example" name="loanscheme" id="loanscheme">
											<option value="">Select Loan Scheme</option>
                  							
                                           <?php $__currentLoopData = $loan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($loans->id); ?>"
                                                        <?php if($editloanapp->id_of_loan_scheme==$loans->id): ?> selected <?php endif; ?>><?php echo e($loans->loan_scheme_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                                              						</select>
										

									</div>

									<div class="col-md-2">
										<label>Select Customer</label>
										<select class="form-select "
											aria-label="Default select example" id="customer" name="customer">
											<option selected>Select Customer</option>
											<?php $__currentLoopData = $cust; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($customer->id); ?>"   <?php if($editloanapp->id_of_customer==$customer->id): ?> selected <?php endif; ?>><?php echo e($customer->customer_name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>									</select>

										</select>

									</div>

									

									<div class="col-md-2">
										<label for="inputFirstName" >City</label>
										<input type="text" class="form-control" id="city" placeholder="City" name="city" value="<?php echo e($editloanapp->id_of_city); ?>" >
									</div>
									
									<div class="col-md-2">
										<label for="inputFirstName" >Loan Amount*</label>
										<input type="text" class="form-control" id="loanamount" placeholder="Loan Amount" name="amount" value="<?php echo e($editloanapp->amount); ?>" >
									</div>

									<div class="col-md-2">
										<label>Select Tenure Type</label>
										<select class="form-select "
											aria-label="Default select example" id="" name="tenure" value="<?php echo e($editloanapp->tenure_type); ?>">
											<option selected>By Month</option>
											<option selected>By Day</option>

										</select>

									</div>

									

									<div class="col-md-2">
										<label for="inputFirstName" >Tenure</label>
										<input type="number" class="form-control" id="inputFirstName" placeholder="Tenure" name="tenure_for_days" value="<?php echo e($editloanapp->tenure_for_days); ?>">
									</div>

									<div class="col-md-2">
										<label for="inputFirstName" >Alternative Number*</label>
										<input type="number" class="form-control" id="alterno" placeholder="Alternative Number" name="alternative_number" value="<?php echo e($editloanapp->alternative_mobile_number); ?>">
									</div>

									<div class="col-md-2">
										<label for="inputFirstName" >Intrest Amount*</label>
										<input type="number" class="form-control"  placeholder="Intrest" id="intrest" name="intrest" value="<?php echo e($editloanapp->intrest); ?>">
									</div>

											
									<div class="col-md-2">
										<label for="inputFirstName" >Application Fees*</label>
										<input type="number" class="form-control"  placeholder="Application fees" id="appfees" name="application_fees" value="<?php echo e($editloanapp->application_fees); ?>">
									</div>
									
									
									
									<div class="col-md-2">
										<label for="inputFirstName" >Processing Fees*</label>
										<input type="number" class="form-control"  placeholder="Processing fees" id="procfees" name="processing_fees" value="<?php echo e($editloanapp->processing_fees); ?>">
									</div>
									<div class="col-md-2">
										<label for="inputFirstName" >Valuation Fees*</label>
										<input type="number" class="form-control"  placeholder="Valuation Fees" id="valufees" name="valuation_fees" value="<?php echo e($editloanapp->valuation_fees); ?>">
									</div>
									<div class="col-md-2">
										<label for="inputFirstName" >Disburse Amount*</label>
										<input type="text" class="form-control" id="disburamount" placeholder="Disburse Amount" name="disburse_amount" value="<?php echo e($editloanapp->disburse_amount); ?>">
									</div>

									
									<div class="col-md-2">
										<label for="inputFirstName" >Repayment Amount*</label>
										<input type="text" class="form-control" id="repayment" placeholder="Repayment Amount" name="Repayment" value="<?php echo e($editloanapp->repayment); ?>">
									</div>
									<div class="col-md-3">
										<label for="inputFirstName" >Expected Date Of Disbursment*</label>
										<input type="Date" class="form-control" id="inputFirstName" placeholder="Disburse Amount" name="date_of_disbursment"  value="<?php echo e($editloanapp->expected_date_of_disbursment); ?>">
									</div>
									<div class="col-md-2" style="padding:8px" ><br>
										<button type="submit" class="btn btn-primary px-3"><i class="fadeIn animated bx bx-plus"></i>Add</button>
									</div>
								</form>
		
							</div>
		
						</div>
					</div> 
				
					<hr />

					





<?php $__env->stopSection(); ?> 

    





<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nidhibank\resources\views/edit_loan_application.blade.php ENDPATH**/ ?>