
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
			<div class="page-content">
				<div class="row">
					<div class="col-md-12 mx-auto" >
						<div class="card">
							<div class="card-body">
								<div class="card-title d-flex align-items-center">
								
									<h5 class="mb-0 text-primary">Loan Application</h5>
								</div>
								<hr>
								<form class="row g-2">
								
								
									<div class="col-md-3">
										<label>Select Loan Scheme*</label>
										<select class="form-select "
											aria-label="Default select example">
											<option selected>Select Loan Scheme</option>
											<option></option>

										</select>

									</div>

									<div class="col-md-3">
										<label>Select Customer*</label>
										<select class="form-select "
											aria-label="Default select example">
											<option selected>Select Customer</option>
											<option></option>

										</select>

									</div>

									<div class="col-md-3">
										<label>Select City*</label>
										<select class="form-select "
											aria-label="Default select example">
											<option selected>Select City</option>
											<option></option>

										</select>

									</div>

									
									<div class="col-md-3">
										<label for="inputFirstName" >Amount*</label>
										<input type="text" class="form-control" id="inputFirstName" placeholder="Amount">
									</div>

									<div class="col-md-3">
										<label for="inputFirstName" >Tenure/Month*</label>
										<input type="text" class="form-control" id="inputFirstName" placeholder="Tenure/Month">
									</div>

									<div class="col-md-3">
										<label for="inputFirstName" >Alternative Number*</label>
										<input type="text" class="form-control" id="inputFirstName" placeholder="Alternative Number">
									</div>

									<div class="col-md-3">
										<label for="inputFirstName" >Intrest*</label>
										<input type="text" class="form-control" id="inputFirstName" placeholder="Intrest">
									</div>

											
									<div class="col-md-3">
										<label for="inputFirstName" >Application Fees*</label>
										<input type="text" class="form-control" id="inputFirstName" placeholder="Application fees">
									</div>

									<div class="col-md-3">
										<label for="inputFirstName" >Processing Fees*</label>
										<input type="text" class="form-control" id="inputFirstName" placeholder="Processing fees">
									</div>
									<div class="col-md-3">
										<label for="inputFirstName" >Valuation Fees*</label>
										<input type="text" class="form-control" id="inputFirstName" placeholder="Valuation Fees">
									</div>


									<div class="col-md-3" style="padding:8px" ><br>
										<button type="submit" class="btn btn-primary px-3"><i class="fadeIn animated bx bx-plus"></i>Add</button>
									</div>
								</form>
		
							</div>
		
						</div>
					</div> 
				
					<hr />

					<div class="col-md-12" >
						<div class="card">
							<div class="card-body">
								<div class="table-responsive">
									<table id="example" class="table table-striped table-bordered">
										<thead>
											<tr>
												<th>Sr. No.</th>
												<th>Loan Account No.</th>  
												<th>Loan Amount</th> 
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>1</td>
												<td></td>
												<td></td>
											
												<td><button type="button" class="btn1 btn-outline-success"><i class='bx bx-edit-alt me-0'></i></button>
													 <button type="button" class="btn1 btn-outline-danger"><i class='bx bx-trash me-0'></i></button> 
													 <button type="button" class="btn1 btn-outline-dark" data-bs-toggle="modal" data-bs-target="#exampleLargeModal">Schedule</button> 
													 <a href="disbursement.html"><button type="button" class="btn1 btn-outline-primary">Disbursement</button> </a>
												</td>
									
											</tr>
											
										
											
										</tbody>
									</table>
								</div>
							</div>
						</div>
					
					</div>

				</div>
				
			</div>
		</div>
		<div class="col">
			<!-- Button trigger modal -->
			<!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleLargeModal">Large Modal</button> -->
			<!-- Modal -->
			<div class="modal fade" id="exampleLargeModal" tabindex="-1" aria-hidden="true">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title">Schedule</h5>
							<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
						</div>
						<div class="modal-body"><h6 class="mb-0 text-uppercase">Schedule</h6>
							<hr/>
							<div class="card">
								<div class="card-body">
									<table class="table mb-0 table-striped">
										<thead>
											<tr>
												<th scope="col">Sr No</th>
												<th scope="col">Installment Number</th>
												<th scope="col">Due Date</th>
												<th scope="col">Installment Amount</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<th scope="row">1</th>
												<td>0976</td>
												<td>22/feb/2023</td>
												<td>1,000</td>
											</tr>
										
										</tbody>
									</table>
								</div>
							</div></div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
							<button type="button" class="btn btn-primary">Save changes</button>
						</div>
					</div>
				</div>
			</div>
		</div>

@strpos






<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel\nidhi_bank\resources\views/loan_application.blade.php ENDPATH**/ ?>