
<?php $__env->startSection("content"); ?>
<div class="page-wrapper">
			<div class="page-content">
				<div class="row">
					<div class="col-md-12 mx-auto" >
						<div class="card">
							<div class="card-body">
								<div class="card-title d-flex align-items-center">
								
									<h5 class="mb-0 text-primary">Add Customer</h5>
								</div>
								<hr>
								<form class="row g-2">
									<!-- <div class="col-md-3">
										<label class="form-label">
											Date of Sale</label>
										<input class="result form-control" type="text" id="date" placeholder="">
									</div> -->
									<div class="col-md-2">
										<label for="inputFirstName" class="form-label">Customer Name*</label>
										<input type="text" class="form-control" value="<?php echo e($edit_data->customer_name); ?>" id="inputFirstName" placeholder="Customer Name" required>
									</div>

									
									<div class="col-md-3">
										<label for="inputFirstName" class="form-label">Email*</label>
										<input type="text" class="form-control"  value="<?php echo e($edit_data->email); ?>" id="inputFirstName" placeholder="Email" required>
									</div>

									<div class="col-md-2">
										<label for="inputFirstName" class="form-label">Whtasaap Number*</label>
										<input type="text" class="form-control" value="<?php echo e($edit_data->whatsapp_number); ?>" id="inputFirstName" placeholder="Whtasaap Number" required>
									</div>
									<div class="col-md-2">
										<label for="inputFirstName" class="form-label">Alternative Number*</label>
										<input type="text" class="form-control" value="<?php echo e($edit_data->alternative_number); ?>" id="inputFirstName" placeholder="Alternative Number" required>
									</div>

									
									<div class="col-md-3">
										<label for="inputFirstName" class="form-label">Address*</label>
										<input type="text" class="form-control" value="<?php echo e($edit_data->address); ?>" id="inputFirstName" placeholder="Address" required>
									</div>

											
									<div class="col-md-2">
										<label for="inputFirstName" class="form-label">City*</label>
										<input type="text" class="form-control" value="<?php echo e($edit_data->city); ?>" id="inputFirstName" placeholder="City" required>
									</div>

									<div class="col-md-2">
										<label for="inputFirstName" class="form-label">PAN</label>
										<input class="form-control" value="<?php echo e($edit_data->PAN); ?>" id="fancy-file-upload" type="file" name="files" accept=".jpg, .png, image/jpeg, image/png" required>
									</div>

									
									<div class="col-md-2">
										<label for="inputFirstName" class="form-label">Aadhar</label>
										<input class="form-control" value="<?php echo e($edit_data->aadhar); ?>" id="fancy-file-upload" type="file" name="files" accept=".jpg, .png, image/jpeg, image/png" required>
									</div>

								

									<div class="col-md-1"  >
                                    <label for="inputFirstName" class="form-label" style="opacity:0;"> button </label>
										<button type="submit" class="btn btn-primary form-control" >UPDATE</button>
									</div>
								</form>
		
							</div>
		
						</div>
					</div>

					<hr/>

					<div class="col-md-12" >
						<div class="card">
							<div class="card-body">
								<div class="table-responsive">
									<table id="example" class="table table-striped table-bordered">
										<thead>
											<tr>
												<th>Sr. No.</th>
												<th> Name</th>  
												<th>Email</th> 
												<th>Whtasaap Number</th>
												<th>Alternative Number</th>
												<th>Address</th>
												<th>City</th>
												<th>Aadhar</th>
												<th>PAN</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c_dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><?php echo e($loop->index+1); ?></td>
						     					<td><?php echo e($c_dt->customer_name); ?></td>
												<td><?php echo e($c_dt->email); ?></td>
												<td><?php echo e($c_dt->whatsapp_number); ?></td>
												<td><?php echo e($c_dt->alternetive_number); ?></td>
												<td><?php echo e($c_dt->address); ?></td>
												<td><?php echo e($c_dt->city); ?></td>
												<td><?php echo e($c_dt->pan); ?></td>
												<td><?php echo e($c_dt->aadhar); ?></td>
												<td>
												<a href="<?php echo e(route('edit_customer',$c_dt)); ?>"><button type="button" class="btn1 btn-outline-success"><i class='bx bx-edit-alt me-0'></i></button> </a>
												<a href="<?php echo e(route('delete_customer',$c_dt)); ?>"><button type="button" class="btn1 btn-outline-danger"><i class='bx bx-trash me-0'></i></button> </a>
												</td>
									
											</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
										
											
										</tbody>
									</table>
								</div>
							</div>
						</div>
					
					</div>

				</div>
				
			</div>
		</div>

				
		<!--end page wrapper -->
		<!--start overlay-->
		<div class="overlay toggle-icon"></div>
		<!--end overlay-->
		<!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
		<!--End Back To Top Button-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel\nidhi_bank\resources\views/edit_customer.blade.php ENDPATH**/ ?>