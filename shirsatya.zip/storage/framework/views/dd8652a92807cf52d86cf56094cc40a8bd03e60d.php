
<?php $__env->startSection("content"); ?>
<div class="page-wrapper">
			<div class="page-content">
				<div class="row">
					<div class="col-md-12 mx-auto" >
						<div class="card">
							<div class="card-body">
								<div class="card-title d-flex align-items-center">
								
									<h5 class="mb-0 text-primary">Add Customer</h5>
								</div>
								<hr>
								<form class="row g-2" method='post' action="<?php echo e(route('add_customer')); ?>" enctype="multipart/form-data">
									<?php echo csrf_field(); ?>
									
									<!-- <div class="col-md-3">
										<label class="form-label">
											Date of Sale</label>
										<input class="result form-control" type="text" id="date" placeholder="">
									</div> -->
									<div class="col-md-2">
					     				<label for="inputFirstName" class="form-label">Customer Name*</label>
										<input type="text" name="customer_name" class="form-control" id="inputFirstName" placeholder="Customer Name" required>
									</div>

									
									<div class="col-md-2">
										<label for="inputFirstName" class="form-label">Email*</label>
										<input type="text" name="email" class="form-control" id="inputFirstName" placeholder="Email" required>
									</div>

									<div class="col-md-2">
										<label for="inputFirstName" class="form-label">WhatsApp Number*</label>
										<input type="text" name="whatsapp_number" class="form-control" id="inputFirstName" placeholder="WhatsApp Number" required>
									</div>
									<div class="col-md-2">
										<label for="inputFirstName" class="form-label">Alternative Number*</label>
										<input type="text" name="alternetive_number" class="form-control" id="inputFirstName" placeholder="Alternative Number" required>
									</div>

									
									<div class="col-md-2">
										<label for="inputFirstName" class="form-label">Address*</label>
										<input type="text" name="address" class="form-control" id="inputFirstName" placeholder="Address" required>
									</div>

											
									<div class="col-md-2">
										<label for="inputFirstName" class="form-label">City*</label>
										<select class="form-select mb-3" aria-label="Default select example" name="city">
											
											<option value="">Select City</option>
		                                                 							
                                                <?php $__currentLoopData = $customer_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $citys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($citys->id); ?>"><?php echo e($citys->city); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>									</select>
									</div>

									
									
								
									<div class="col-md-3">
										<label for="inputFirstName" class="form-label">Photo</label>
										<input class="form-control" id="fancy-file-upload" type="file" name="imagess" accept=".jpg, .png, image/jpeg, image/png" required>
									</div>
									<div class="col-md-3">
										<label for="inputFirstName" class="form-label">PAN</label>
										<input class="form-control" id="fancy-file-upload" type="file" name="image" accept=".jpg, .png, image/jpeg, image/png" required>
									</div>
									<div class="col-md-3">
										<label for="inputFirstName" class="form-label">Aadhar</label>
										<input class="form-control" name="images" id="fancy-file-upload" type="file" accept=".jpg, .png, image/jpeg, image/png" required>
									</div>
									<div class="col-md-3" style="padding:10px; margin-top: 2%">
									
										<button type="submit" class="btn btn-primary px-3"><i class="fadeIn animated bx bx-plus"></i>Add</button>
									</div>
									<br>
								</form>
		
							</div>
		
						</div>
					</div>

					<hr/>

					<div class="col-md-12" >
						<div class="card">
							<div class="card-body">
								<div class="table-responsive">
									<table id="example" class="table table-striped table-bordered">
										<thead>
											<tr>
												<th>Sr. No.</th>
												<th> Name</th>  
												<th>Email</th> 
												<th>WhatsApp Number</th>
												<th>Alternative Number</th>
												<th>Address</th>
												<th>City</th>
												<th>Photo</th>
												<th>PAN</th>
												<th>Aadhar</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<?php $__currentLoopData = $cust; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c_dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><?php echo e($loop->index+1); ?></td>
						     					<td><?php echo e($c_dt->customer_name); ?></td>
												<td><?php echo e($c_dt->email); ?></td>
												<td><?php echo e($c_dt->whatsapp_number); ?></td>
												<td><?php echo e($c_dt->alternetive_number); ?></td>
												<td><?php echo e($c_dt->address); ?></td>
												<td><?php echo e($c_dt->city); ?></td>
												
												
												<td><a href="<?php echo e(asset('/')); ?><?php echo e($c_dt->photo); ?>"> 
													<img height="50px" width="50px" src="<?php echo e(asset('/')); ?><?php echo e($c_dt->photo); ?>" alt="" /></a>
												</td>
												<td><a href="<?php echo e(asset('/')); ?><?php echo e($c_dt->pan); ?>"> 
													<img height="50px" width="50px" src="<?php echo e(asset('/')); ?><?php echo e($c_dt->pan); ?>" alt="" /></a>
												</td>
							<td><a href="<?php echo e(asset('/')); ?><?php echo e($c_dt->adhar); ?>"> 
													<img height="50px" width="50px" src="<?php echo e(asset('/')); ?><?php echo e($c_dt->adhar); ?>" alt="" /></a>
												</td>
											
												<td>
												<a href="<?php echo e(route('edit_customer',$c_dt)); ?>">
													<button type="button" class="btn1 btn-outline-success"><i class='bx bx-edit-alt me-0'></i></button> </a>
												<a href="<?php echo e(route('delete_customer',$c_dt)); ?>"><button type="button" class="btn1 btn-outline-danger"><i class='bx bx-trash me-0'></i></button> </a>
												</td>
									
											</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
										
											
										</tbody>
									</table>
								</div>
							</div>
						</div>
					
					</div>

				</div>
				
			</div>
		</div>

				
		<!--end page wrapper -->
		<!--start overlay-->
		<div class="overlay toggle-icon"></div>
		<!--end overlay-->
		<!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
		<!--End Back To Top Button-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/sheikhproperties.in/webmediaindia.co.in/NidhiBank/resources/views/customer.blade.php ENDPATH**/ ?>