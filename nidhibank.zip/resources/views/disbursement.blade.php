@extends('layout')
@section('content')
<div class="page-wrapper">
			<div class="page-content">
				<div class="row">
					<h5 class="mb-0 text-primary" >Disbursement</h5>
					<hr/ style="margin-top: -5%;">

					<div class="col-md-12" style="margin-top: -3%;">
						<div class="card">
							<div class="card-body">
								<div class="table-responsive">
									<table id="example" class="table table-striped table-bordered">
										<thead>
											<tr>
												<th>Sr. No.</th>
												<th> Customer Name</th>  
												<th>EMI Number</th> 
												<th>EMI Amount</th>
												<th>EMI Pendings</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>1</td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
											
												<td><button type="button" class="btn1 btn-outline-success"><i class='bx bx-edit-alt me-0'></i></button> <button type="button" class="btn1 btn-outline-danger"><i class='bx bx-trash me-0'></i></button> 
												</td>
									
											</tr>
											
										
											
										</tbody>
									</table>
								</div>
							</div>
						</div>
					
					</div>

				</div>
				
			</div>
		</div>
        @stop